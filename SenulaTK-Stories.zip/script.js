const text = document.querySelector('.typewriter'); // Select your text element
const words = ["Welcome", "to", "SenulaTK", "Stories"]; // Your words to display
let i = 0;
let j = 0;

function type() {
  if (j < words[i].length) {
    text.textContent += words[i][j];
    j++;
    setTimeout(type, 100); // Adjust speed here
  } else {
    j = 0;
    i = (i + 1) % words.length;
    setTimeout(type, 2000); // Adjust delay between words
  }
}

type(); // Start the typewriter effect